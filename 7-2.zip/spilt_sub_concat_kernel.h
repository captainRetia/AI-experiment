extern "C" {
    // TODO：完成SBCKernel接口定义
    void SBCKernel(half* input_data_, half* output_data_, int batch_num_);

}

